# MangaVerse

Website đọc truyện tranh cá nhân, ưu tiên Android, xây dựng bằng React + TypeScript + Vite + Tailwind CSS + React Router. Dự án dùng `HashRouter` và đường dẫn tài nguyên tương đối để phù hợp với GitHub Pages.

> **Lưu ý nội dung:** thư viện được để trống khi cài mới. MangaVerse không tự chép hoặc nhúng truyện có bản quyền. Bạn tự thêm metadata, chương và URL ảnh mà bạn có quyền sử dụng.

## Tính năng hiện có

- Trang chủ, thư viện, tìm kiếm cục bộ, bộ lọc định dạng/trạng thái/thể loại và sắp xếp.
- Trang chi tiết bộ truyện, danh sách chương, đánh dấu yêu thích/theo dõi.
- Trình đọc cuộn dọc và từng trang, thanh tiến trình, lưu trang đọc gần nhất, chuyển chương, toàn màn hình, chế độ ban đêm, zoom ở chế độ từng trang.
- Tủ sách, lịch sử đọc, hồ sơ khách, giao diện sáng/tối.
- Xuất/nhập bản sao lưu JSON.
- Khu vực quản lý cục bộ: thêm/sửa/xóa truyện; thêm/xóa chương; khai báo URL ảnh bìa và ảnh từng trang.
- Trang Khám phá dùng AniList GraphQL để tìm metadata manga. Kết quả chỉ được thêm vào thư viện khi bạn chủ động bấm nút.
- Có 3 ảnh SVG tự tạo để xem thử trình đọc. Đây là artwork trình diễn, không phải một bộ truyện.
- GitHub Actions tự build và deploy GitHub Pages khi push lên nhánh `main`.

## Chạy thử trên máy tính

Cần Node.js 20 trở lên (workflow GitHub Pages dùng Node 22).

```bash
npm install
npm run dev
```

Mở địa chỉ Vite hiển thị trong terminal. Để tạo bản build:

```bash
npm run build
npm run preview
```

Thư mục đầu ra sau khi build là `dist/`.

## Đưa dự án lên GitHub bằng điện thoại Android

1. Mở Chrome và đăng nhập GitHub: <https://github.com>.
2. Tạo repository mới, ví dụ tên `mangaverse`. Chọn **Public** nếu bạn muốn dùng GitHub Pages miễn phí cho repository dạng project, và có thể để repository trống.
3. Tải ZIP dự án về điện thoại, giải nén bằng ứng dụng quản lý tệp.
4. Mở repository vừa tạo. Chọn **Add file → Upload files** và tải nội dung dự án đã giải nén lên repository, giữ nguyên cấu trúc thư mục (`src`, `public`, `.github`, ...). Commit lên nhánh `main`.
5. Mở **Settings → Pages**. Ở phần **Build and deployment**, chọn **GitHub Actions** làm Source.
6. Mở tab **Actions**. Workflow `Deploy MangaVerse to GitHub Pages` sẽ tự chạy sau commit. Khi workflow hoàn tất, GitHub hiển thị liên kết website ở phần Pages hoặc trong log deploy.
7. Mỗi lần sửa mã nguồn rồi commit lên `main`, website sẽ được build và deploy lại tự động.

Nếu giao diện GitHub trên điện thoại không hiển thị được thao tác tải nhiều tệp/thư mục, hãy bật **Trang web cho máy tính** trong Chrome hoặc mở repository bằng trình chỉnh sửa web `github.dev` để thao tác với tệp. Không tải riêng file ZIP lên repository thay cho mã nguồn đã giải nén.

## Cách thêm truyện

1. Mở MangaVerse và vào **Quản lý nội dung**.
2. Trong mục **Tạo bộ truyện mới**, nhập tên, định dạng, trạng thái, bìa, tác giả, mô tả và thể loại. Thể loại phân cách bằng dấu phẩy, ví dụ `Fantasy, Action, Isekai`.
3. Trong **Thêm chương và ảnh trang**, chọn bộ truyện, nhập số chương và tên chương.
4. Dán URL ảnh theo đúng thứ tự, mỗi URL trên một dòng. Có thể dùng URL `https://...` hoặc đường dẫn tương đối của ảnh đã được đưa vào thư mục `public/` trong repository (ví dụ `./manga/my-title/chapter-01/01.jpg`).
5. Bấm **Lưu chương**. Chọn một chương để mở trình đọc.

**Mẹo:** với ảnh muốn hiển thị ổn định trên website công khai, nên đặt ảnh được cấp phép trong repository (hoặc một dịch vụ lưu trữ ảnh mà bạn có quyền dùng), sau đó dùng đường dẫn tương đối/URL công khai. Không nên dán URL ảnh từ website khác khi chưa biết điều khoản sử dụng.

## AniList API

Trang Khám phá gửi GraphQL `POST` đến `https://graphql.anilist.co`. Dữ liệu có thể dùng gồm tên, bìa, mô tả, thể loại, điểm, trạng thái, năm phát hành và một số thông tin staff khi AniList có cung cấp. AniList không phải nguồn ảnh trang chương trong trình đọc.

Tài liệu chính thức:

- [AniList API — Getting Started](https://docs.anilist.co/guide/graphql/)
- [AniList API — Media queries](https://docs.anilist.co/guide/graphql/queries/media)
- [AniList API — Media reference](https://docs.anilist.co/reference/object/media)

## Lưu trữ và giới hạn

- Dữ liệu truyện, tủ sách, tiến trình đọc, lịch sử tìm kiếm và tùy chọn giao diện được lưu bằng `localStorage` trên trình duyệt hiện tại.
- Không có đăng nhập, backend, database, đồng bộ đa thiết bị hay đồng bộ giữa người dùng.
- Mục Quản lý nội dung hiện là công cụ nhập dữ liệu local, **không phải trang admin được bảo vệ**. Ai có quyền truy cập website trên cùng trình duyệt có thể mở route này và thao tác dữ liệu local. Không đưa website vào vận hành công khai như một nền tảng cho nhiều người dùng trước khi bổ sung backend, xác thực, phân quyền và API lưu trữ.
- Ảnh chương được nạp từ các URL bạn khai báo. Máy chủ ảnh bên ngoài có thể chặn hotlink, giới hạn truy cập hoặc thay đổi URL.
- LocalStorage có giới hạn dung lượng; nên dùng URL ảnh hoặc đường dẫn public, không nhúng ảnh truyện lớn thành data URL.
- AniList là dịch vụ bên thứ ba; nếu API bị lỗi/giới hạn hoặc không có mạng, chức năng Khám phá sẽ thông báo lỗi. Thư viện local vẫn hoạt động.

## Cấu trúc thư mục

```text
mangaverse/
├── .github/workflows/deploy.yml
├── public/
│   ├── favicon.svg
│   └── reader-demo/           # Ảnh SVG trình diễn trình đọc
├── src/
│   ├── components/            # AppShell, MangaCard, EmptyState
│   ├── lib/                   # LocalStorage, AniList GraphQL
│   ├── pages/                 # Home, Library, Discover, Detail, Reader, Shelf, Profile, Admin
│   ├── App.tsx
│   ├── main.tsx
│   ├── store.tsx
│   ├── styles.css
│   └── types.ts
├── index.html
├── package.json
├── vite.config.ts
└── README.md
```

## Gợi ý phát triển tiếp

- Backend (ví dụ Supabase/Firebase hoặc API riêng) để quản lý tài khoản, truyện, chương và phân quyền admin.
- Lưu tệp ảnh lên object storage/CDN và phân phối ảnh theo quyền sử dụng.
- Đồng bộ tủ sách và tiến trình đọc giữa các thiết bị.
- Tách quyền quản trị khỏi frontend và bảo vệ mọi endpoint ghi dữ liệu ở backend.
- Thêm kiểm thử tự động cho các luồng thêm truyện, thêm chương và lưu tiến trình đọc.

## Bản quyền

MangaVerse là bộ khung website và trình đọc. Người triển khai chịu trách nhiệm bảo đảm quyền phân phối đối với mọi ảnh bìa, ảnh chương, bản dịch, nội dung và dữ liệu do mình đưa lên.
