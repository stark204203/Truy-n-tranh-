export type MangaFormat = 'Manga' | 'Manhwa' | 'Manhua' | 'Webtoon' | 'Other';
export type MangaStatus = 'Đang tiến hành' | 'Đã hoàn thành' | 'Tạm ngưng';
export type ReadingMode = 'vertical' | 'single';

export interface Chapter {
  id: string;
  number: number;
  title: string;
  updatedAt: string;
  pages: string[];
}

export interface Manga {
  id: string;
  title: string;
  altTitle?: string;
  format: MangaFormat;
  cover: string;
  description: string;
  author: string;
  artist: string;
  country: string;
  status: MangaStatus;
  year: number | null;
  score: number | null;
  genres: string[];
  chapters: Chapter[];
  source?: 'local' | 'anilist';
  externalUrl?: string;
}

export interface ShelfEntry {
  mangaId: string;
  favorite: boolean;
  following: boolean;
  completed: boolean;
  addedAt: string;
}

export interface ReadProgress {
  mangaId: string;
  chapterId: string;
  page: number;
  mode: ReadingMode;
  updatedAt: string;
}

export interface AniListManga {
  id: number;
  title: { romaji?: string | null; english?: string | null; native?: string | null };
  coverImage: { extraLarge?: string | null; large?: string | null };
  description?: string | null;
  genres?: string[];
  averageScore?: number | null;
  status?: string | null;
  format?: string | null;
  chapters?: number | null;
  startDate?: { year?: number | null } | null;
  countryOfOrigin?: string | null;
  siteUrl?: string | null;
  staff?: { edges?: Array<{ role?: string; node?: { name?: { full?: string | null } } }> };
}
