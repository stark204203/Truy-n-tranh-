import { HashRouter, Route, Routes } from 'react-router-dom';
import { StoreProvider } from './store';
import AppShell from './components/AppShell';
import HomePage from './pages/HomePage';
import LibraryPage from './pages/LibraryPage';
import DiscoverPage from './pages/DiscoverPage';
import MangaPage from './pages/MangaPage';
import ReaderPage from './pages/ReaderPage';
import ShelfPage from './pages/ShelfPage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';

function NotFoundPage() {
  return <div className="page not-found"><div className="eyebrow">404 · PAGE NOT FOUND</div><h1>Trang này chưa tồn tại</h1><p>Đường dẫn có thể đã thay đổi hoặc không còn khả dụng.</p><a className="btn btn-primary" href="#/">Về trang chủ</a></div>;
}

export default function App() {
  return <StoreProvider><HashRouter><Routes><Route element={<AppShell />}><Route index element={<HomePage />} /><Route path="library" element={<LibraryPage />} /><Route path="discover" element={<DiscoverPage />} /><Route path="manga/:id" element={<MangaPage />} /><Route path="shelf" element={<ShelfPage />} /><Route path="profile" element={<ProfilePage />} /><Route path="admin" element={<AdminPage />} /></Route><Route path="read-preview" element={<ReaderPage />} /><Route path="read/:mangaId/:chapterId" element={<ReaderPage />} /><Route path="*" element={<NotFoundPage />} /></Routes></HashRouter></StoreProvider>;
}
