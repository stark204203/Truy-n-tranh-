import { useEffect, useState, type FormEvent } from 'react';
import { AlertCircle, ArrowUpRight, BookPlus, LoaderCircle, Search, Sparkles } from 'lucide-react';
import { useStore } from '../store';
import { fromAniList, searchAniList } from '../lib/anilist';
import type { AniListManga } from '../types';
import { Cover } from '../components/MangaCard';

export default function DiscoverPage() {
  const { mangas, setMangas } = useStore();
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [results, setResults] = useState<AniListManga[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!submitted) return;
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLoading(true); setError('');
      try { setResults(await searchAniList(submitted, controller.signal)); }
      catch (err) { if (!controller.signal.aborted) setError(err instanceof Error ? err.message : 'Không thể kết nối AniList.'); }
      finally { if (!controller.signal.aborted) setLoading(false); }
    }, 350);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [submitted]);
  const search = (event: FormEvent) => { event.preventDefault(); if (query.trim()) setSubmitted(query.trim()); };
  const add = (item: AniListManga) => {
    const manga = fromAniList(item);
    if (mangas.some((existing) => existing.id === manga.id)) return;
    setMangas((items) => [manga, ...items]);
  };
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">EXPLORE THE CATALOG</div><h1>Khám phá truyện</h1><p>Tìm thông tin manga từ AniList và tự chọn tác phẩm muốn đưa vào thư viện.</p></div><span className="api-pill"><span /> AniList GraphQL</span></div>
    <form className="discover-search" onSubmit={search}><Search size={20} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Nhập tên manga, manhwa hoặc manhua..." /><button className="btn btn-primary" type="submit" disabled={!query.trim() || loading}>Tìm kiếm</button></form>
    <div className="api-disclaimer"><Sparkles size={17} /><span>AniList cung cấp metadata như tên, bìa, mô tả và thể loại. API không cấp ảnh trang chương để đọc. Bạn cần tự thêm chương và nguồn ảnh được phép sử dụng trong Quản lý nội dung.</span></div>
    {loading && <div className="loading-state"><LoaderCircle className="spin" size={24} /> Đang tìm trên AniList...</div>}
    {error && <div className="error-state"><AlertCircle size={18} /> {error} <button onClick={() => setSubmitted(query.trim())}>Thử lại</button></div>}
    {!loading && !error && submitted && <div className="discover-results"><div className="result-line"><span>Kết quả cho “{submitted}”</span><span>{results.length} tác phẩm</span></div>{results.length ? <div className="discover-list">{results.map((item) => { const exists = mangas.some((manga) => manga.id === `anilist-${item.id}`); const cover = { title: item.title.english || item.title.romaji || 'Untitled', cover: item.coverImage.extraLarge || item.coverImage.large || '' }; return <article className="discover-card" key={item.id}><Cover manga={cover} /><div className="discover-card-main"><div className="discover-card-title">{cover.title}</div><div className="discover-alt">{item.title.romaji || item.title.native || 'Tên khác chưa có'}</div><div className="discover-tags">{(item.genres || []).slice(0, 4).map((genre) => <span key={genre}>{genre}</span>)}</div><p>{(item.description || 'Chưa có mô tả.').replace(/<[^>]*>/g, ' ').slice(0, 190)}{(item.description || '').length > 190 ? '…' : ''}</p><div className="discover-meta">{item.format || 'MANGA'} · {item.startDate?.year || '—'} · {item.averageScore ? `${(item.averageScore / 10).toFixed(1)}★` : 'Chưa có điểm'}</div></div><div className="discover-card-actions"><button className={`btn ${exists ? 'btn-done' : 'btn-primary'}`} onClick={() => add(item)} disabled={exists}>{exists ? 'Đã thêm' : <><BookPlus size={15} /> Thêm vào thư viện</>}</button>{item.siteUrl && <a className="external-link" href={item.siteUrl} target="_blank" rel="noreferrer">AniList <ArrowUpRight size={13} /></a>}</div></article>; })}</div> : <div className="empty-inline">Không tìm thấy tác phẩm. Hãy thử một tên gọi khác bằng tiếng Anh hoặc romaji.</div>}</div>}
    {!submitted && <div className="discover-intro"><div className="discover-orb"><Sparkles size={31} /></div><h2>Thế giới manga rộng lớn đang chờ bạn</h2><p>Tìm theo tên tiếng Anh, romaji hoặc tên gốc. Chọn kết quả phù hợp để nhập thông tin vào thư viện cá nhân.</p></div>}
  </div>;
}
