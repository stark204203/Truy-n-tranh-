import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowDown, ArrowLeft, ArrowUp, BookOpen, Bookmark, CheckCircle2, Clock3, ExternalLink, Heart, Share2, Star } from 'lucide-react';
import { useStore } from '../store';
import { Cover } from '../components/MangaCard';
import type { ShelfEntry } from '../types';

export default function MangaPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const { mangas, shelf, setShelf, progress } = useStore();
  const manga = mangas.find((item) => item.id === id);
  const [descending, setDescending] = useState(true);
  const [chapterSearch, setChapterSearch] = useState('');
  const [shareMessage, setShareMessage] = useState('');
  const entry = shelf.find((item) => item.mangaId === id);
  const chapters = useMemo(() => manga ? [...manga.chapters].sort((a, b) => descending ? b.number - a.number : a.number - b.number).filter((chapter) => `${chapter.number} ${chapter.title}`.toLowerCase().includes(chapterSearch.toLowerCase())) : [], [manga, descending, chapterSearch]);
  if (!manga) return <div className="page"><div className="not-found"><h1>Không tìm thấy truyện</h1><p>Truyện này có thể đã bị xóa khỏi thư viện trên thiết bị.</p><Link className="btn btn-secondary" to="/library"><ArrowLeft size={16} /> Quay lại thư viện</Link></div></div>;
  const latest = [...manga.chapters].sort((a, b) => b.number - a.number)[0];
  const first = [...manga.chapters].sort((a, b) => a.number - b.number)[0];
  const current = progress[id];
  const currentChapter = manga.chapters.find((chapter) => chapter.id === current?.chapterId);
  const toggleShelf = (key: 'favorite' | 'following') => {
    setShelf((items) => {
      const old = items.find((item) => item.mangaId === id);
      if (old) return items.map((item) => item.mangaId === id ? { ...item, [key]: !item[key] } : item);
      return [...items, { mangaId: id, favorite: key === 'favorite', following: key === 'following', completed: false, addedAt: new Date().toISOString() } as ShelfEntry];
    });
  };
  const toggleCompleted = () => {
    setShelf((items) => {
      const old = items.find((item) => item.mangaId === id);
      if (old) return items.map((item) => item.mangaId === id ? { ...item, completed: !item.completed } : item);
      return [...items, { mangaId: id, favorite: false, following: false, completed: true, addedAt: new Date().toISOString() } as ShelfEntry];
    });
  };
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: manga.title, text: manga.description.slice(0, 150), url: window.location.href });
      else { await navigator.clipboard.writeText(window.location.href); setShareMessage('Đã sao chép liên kết.'); }
    } catch { setShareMessage('Không thể chia sẻ trên trình duyệt này.'); }
  };
  return <div className="page detail-page">
    <button className="back-link" onClick={() => navigate(-1)}><ArrowLeft size={16} /> Quay lại</button>
    <section className="detail-hero"><div className="detail-cover"><Cover manga={manga} /></div><div className="detail-info"><div className="eyebrow">{manga.format.toUpperCase()} · {manga.country || 'ORIGIN UNKNOWN'}</div><h1>{manga.title}</h1>{manga.altTitle && <div className="detail-alt">{manga.altTitle}</div>}<div className="detail-badges"><span className="status-dot">{manga.status}</span><span><Star size={14} fill="currentColor" /> {manga.score ? manga.score.toFixed(1) : 'Chưa đánh giá'}</span><span><BookOpen size={14} /> {manga.chapters.length} chương</span></div><div className="detail-facts"><div><small>Tác giả</small><b>{manga.author || 'Chưa cập nhật'}</b></div><div><small>Họa sĩ</small><b>{manga.artist || 'Chưa cập nhật'}</b></div><div><small>Năm phát hành</small><b>{manga.year || '—'}</b></div><div><small>Trạng thái</small><b>{manga.status}</b></div></div><div className="genre-list">{manga.genres.map((genre) => <span key={genre}>{genre}</span>)}</div><div className="detail-actions">{first ? <Link to={`/read/${manga.id}/${currentChapter ? currentChapter.id : first.id}`} className="btn btn-primary"><BookOpen size={17} /> {currentChapter ? 'Đọc tiếp' : 'Đọc từ đầu'}</Link> : <button className="btn btn-primary" disabled><BookOpen size={17} /> Chưa có chương</button>}{latest ? <Link to={`/read/${manga.id}/${latest.id}`} className="btn btn-secondary">Chương mới nhất</Link> : <button className="btn btn-secondary" disabled>Chưa có chương mới</button>}{!first && <Link to="/read-preview" className="btn btn-secondary">Xem thử trình đọc</Link>}<button className={`btn btn-icon-label ${entry?.favorite ? 'is-favorite' : ''}`} onClick={() => toggleShelf('favorite')}><Heart size={17} fill={entry?.favorite ? 'currentColor' : 'none'} /> Yêu thích</button><button className={`btn btn-icon-label ${entry?.following ? 'is-following' : ''}`} onClick={() => toggleShelf('following')}><Bookmark size={17} fill={entry?.following ? 'currentColor' : 'none'} /> Theo dõi</button><button className={`btn btn-icon-label ${entry?.completed ? 'is-following' : ''}`} onClick={toggleCompleted}><CheckCircle2 size={17} /> {entry?.completed ? 'Đã hoàn thành' : 'Đánh dấu xong'}</button><button className="icon-btn share-btn" onClick={share} aria-label="Chia sẻ"><Share2 size={17} /></button></div>{shareMessage && <div className="tiny-feedback">{shareMessage}</div>}{manga.externalUrl && <a className="external-link detail-external" href={manga.externalUrl} target="_blank" rel="noreferrer">Nguồn thông tin AniList <ExternalLink size={13} /></a>}</div></section>
    <section className="detail-description"><div className="section-heading"><div><div className="eyebrow">STORY OVERVIEW</div><h2>Giới thiệu</h2></div></div><p>{manga.description || 'Chưa có mô tả cho bộ truyện này.'}</p></section>
    <section className="chapter-section"><div className="section-heading"><div><div className="eyebrow">READING LIST</div><h2>Danh sách chương <span className="muted-count">({manga.chapters.length})</span></h2></div><button className="sort-chapters" onClick={() => setDescending((value) => !value)}>{descending ? <ArrowDown size={15} /> : <ArrowUp size={15} />} {descending ? 'Mới nhất trước' : 'Cũ nhất trước'}</button></div><input className="chapter-search" placeholder="Tìm số chương hoặc tên chương..." value={chapterSearch} onChange={(e) => setChapterSearch(e.target.value)} />{chapters.length ? <div className="chapter-list">{chapters.map((chapter) => <Link to={`/read/${manga.id}/${chapter.id}`} className="chapter-row" key={chapter.id}><div className="chapter-number">CH. {chapter.number.toString().padStart(2, '0')}</div><div className="chapter-row-title">{chapter.title || `Chương ${chapter.number}`}{current?.chapterId === chapter.id && <span className="reading-label">Đang đọc</span>}</div><div className="chapter-date"><Clock3 size={13} /> {new Date(chapter.updatedAt).toLocaleDateString('vi-VN')}</div><ArrowLeft className="chapter-chevron" size={15} /></Link>)}</div> : <div className="empty-inline">{chapterSearch ? 'Không có chương phù hợp với từ khóa.' : 'Chưa có chương nào. Bạn có thể thêm chương trong Quản lý nội dung.'}</div>}</section>
  </div>;
}
