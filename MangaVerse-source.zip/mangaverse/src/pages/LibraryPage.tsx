import { useMemo, useState, type ChangeEvent } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { ArrowDownUp, Filter, Plus, Search, SlidersHorizontal, X } from 'lucide-react';
import { useStore } from '../store';
import { EmptyState, MangaCard, SectionHeading } from '../components/MangaCard';

const formats = ['Tất cả', 'Manga', 'Manhwa', 'Manhua', 'Webtoon', 'Other'];
const statuses = ['Tất cả', 'Đang tiến hành', 'Đã hoàn thành', 'Tạm ngưng'];
const genres = ['Fantasy', 'Action', 'Adventure', 'Isekai', 'Magic', 'Romance', 'Comedy', 'Horror', 'Mystery', 'Drama', 'Sci-Fi', 'Martial Arts', 'Dungeon', 'Monster', 'Level Up', 'RPG'];
const sorts = ['Mới cập nhật', 'Mới thêm', 'Điểm cao nhất', 'Tên A–Z'];

export default function LibraryPage() {
  const { mangas, searchHistory, setSearchHistory } = useStore();
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') || '');
  const [format, setFormat] = useState('Tất cả');
  const [status, setStatus] = useState('Tất cả');
  const [genre, setGenre] = useState('Tất cả');
  const [sort, setSort] = useState(sorts[0]);
  const [visible, setVisible] = useState(18);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const filtered = useMemo(() => {
    const q = query.toLocaleLowerCase('vi');
    const result = mangas.filter((manga) => {
      const text = `${manga.title} ${manga.altTitle || ''} ${manga.author} ${manga.artist} ${manga.genres.join(' ')}`.toLocaleLowerCase('vi');
      return (!q || text.includes(q)) && (format === 'Tất cả' || manga.format === format) && (status === 'Tất cả' || manga.status === status) && (genre === 'Tất cả' || manga.genres.some((item) => item.toLowerCase() === genre.toLowerCase()));
    });
    if (sort === 'Điểm cao nhất') result.sort((a, b) => (b.score || 0) - (a.score || 0));
    if (sort === 'Tên A–Z') result.sort((a, b) => a.title.localeCompare(b.title, 'vi'));
    if (sort === 'Mới cập nhật') result.sort((a, b) => { const latest = (m: typeof a) => m.chapters.reduce((date, chapter) => chapter.updatedAt > date ? chapter.updatedAt : date, ''); return latest(b).localeCompare(latest(a)); });
    return result;
  }, [mangas, query, format, status, genre, sort]);
  const onSearch = (event: ChangeEvent<HTMLInputElement>) => { setQuery(event.target.value); setParams(event.target.value ? { q: event.target.value } : {}); setVisible(18); };
  const clear = () => { setQuery(''); setParams({}); };
  const remember = () => { if (query.trim()) setSearchHistory((items) => [query.trim(), ...items.filter((item) => item !== query.trim())].slice(0, 8)); setHistoryOpen(false); };
  const chooseHistory = (item: string) => { setQuery(item); setParams({ q: item }); setHistoryOpen(false); setVisible(18); };
  const clearHistory = () => setSearchHistory([]);
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">YOUR COLLECTION</div><h1>Thư viện truyện</h1><p>Không gian lưu trữ những thế giới bạn yêu thích.</p></div><Link className="btn btn-primary" to="/admin"><Plus size={16} /> Thêm truyện</Link></div>
    <div className="library-tools"><div className="library-search-wrap"><label className="library-search"><Search size={17} /><input value={query} onChange={onSearch} onFocus={() => setHistoryOpen(true)} onBlur={() => window.setTimeout(() => setHistoryOpen(false), 180)} onKeyDown={(e) => e.key === 'Enter' && remember()} placeholder="Tìm tên truyện, tác giả, thể loại..." />{query && <button onClick={clear} aria-label="Xóa tìm kiếm"><X size={16} /></button>}</label>{historyOpen && !query && searchHistory.length > 0 && <div className="search-history"><div><b>Tìm kiếm gần đây</b><button onMouseDown={(e) => e.preventDefault()} onClick={clearHistory}>Xóa lịch sử</button></div>{searchHistory.map((item) => <button key={item} onMouseDown={(e) => e.preventDefault()} onClick={() => chooseHistory(item)}><Search size={13} /> {item}</button>)}</div>}</div><button className={`filter-toggle ${filtersOpen ? 'selected' : ''}`} onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={16} /> Bộ lọc</button><label className="sort-select"><ArrowDownUp size={15} /><select value={sort} onChange={(e) => setSort(e.target.value)}>{sorts.map((item) => <option key={item}>{item}</option>)}</select></label></div>
    {filtersOpen && <div className="filter-panel"><label>Định dạng<select value={format} onChange={(e) => setFormat(e.target.value)}>{formats.map((item) => <option key={item}>{item}</option>)}</select></label><label>Trạng thái<select value={status} onChange={(e) => setStatus(e.target.value)}>{statuses.map((item) => <option key={item}>{item}</option>)}</select></label><label>Thể loại<select value={genre} onChange={(e) => setGenre(e.target.value)}><option>Tất cả</option>{genres.map((item) => <option key={item}>{item}</option>)}</select></label><button className="clear-filter" onClick={() => { setFormat('Tất cả'); setStatus('Tất cả'); setGenre('Tất cả'); }}>Xóa bộ lọc</button></div>}
    <div className="result-line"><span>{filtered.length} kết quả</span><span>{query ? `Từ khóa: “${query}”` : 'Hiển thị bộ sưu tập cá nhân'}</span></div>
    {filtered.length ? <><div className="manga-grid">{filtered.slice(0, visible).map((manga) => <MangaCard key={manga.id} manga={manga} />)}</div>{visible < filtered.length && <button className="btn btn-secondary load-more" onClick={() => setVisible((n) => n + 18)}>Tải thêm truyện</button>}</> : <EmptyState title={query ? 'Không tìm thấy truyện phù hợp' : 'Thư viện đang trống'} text={query ? 'Thử từ khóa khác hoặc kiểm tra bộ lọc hiện tại.' : 'Hãy thêm bộ truyện đầu tiên để bắt đầu xây dựng thư viện MangaVerse của bạn.'} action={query ? <button className="btn btn-secondary" onClick={clear}>Xóa từ khóa</button> : <Link className="btn btn-primary" to="/admin"><Plus size={16} /> Tạo bộ truyện đầu tiên</Link>} />}
    <div className="library-footnote"><Filter size={14} /> Bộ lọc chỉ áp dụng trên những truyện bạn đã thêm vào MangaVerse.</div>
  </div>;
}
