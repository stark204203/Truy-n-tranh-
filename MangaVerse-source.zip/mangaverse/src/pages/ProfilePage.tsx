import { useRef, useState } from 'react';
import { BookOpen, Download, Heart, History, Moon, Sun, Trash2, Upload, UserRound, AlertTriangle, Clock3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { storage } from '../lib/storage';

export default function ProfilePage() {
  const { mangas, shelf, progress, theme, setTheme, setMangas, setShelf, setProgress, setSearchHistory } = useStore();
  const [notice, setNotice] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const readingCount = Object.keys(progress).length;
  const favoriteCount = shelf.filter((item) => item.favorite).length;
  const exportData = () => {
    const backup = { exportedAt: new Date().toISOString(), mangas, shelf, progress, searchHistory: storage.getSearchHistory() };
    const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `mangaverse-backup-${new Date().toISOString().slice(0, 10)}.json`; anchor.click(); URL.revokeObjectURL(url);
    setNotice('Đã tạo tệp sao lưu JSON.');
  };
  const importData = async (file?: File) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!Array.isArray(parsed.mangas) || !Array.isArray(parsed.shelf) || typeof parsed.progress !== 'object') throw new Error('Sai định dạng');
      setMangas(parsed.mangas); setShelf(parsed.shelf); setProgress(parsed.progress); setSearchHistory(Array.isArray(parsed.searchHistory) ? parsed.searchHistory : []);
      setNotice('Đã khôi phục dữ liệu từ bản sao lưu.');
    } catch { setNotice('Không thể nhập tệp này. Hãy chọn bản sao lưu MangaVerse hợp lệ.'); }
    if (fileRef.current) fileRef.current.value = '';
  };
  const clearData = () => {
    if (!window.confirm('Xóa toàn bộ truyện, tủ sách, lịch sử đọc và cài đặt đã lưu trên thiết bị này? Hành động này không thể hoàn tác.')) return;
    storage.clearAll(); setMangas([]); setShelf([]); setProgress({}); setSearchHistory([]); setTheme('dark'); setNotice('Đã xóa dữ liệu MangaVerse trên thiết bị này.');
  };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">YOUR ACCOUNT SPACE</div><h1>Hồ sơ cá nhân</h1><p>Quản lý thư viện và cài đặt trên thiết bị này.</p></div></div>
    <section className="profile-card"><div className="profile-avatar"><UserRound size={34} /></div><div className="profile-name"><h2>Reader</h2><p>Tài khoản khách · Lưu trên thiết bị</p></div><span className="local-badge">LOCAL PROFILE</span></section>
    <div className="stats-grid"><div className="stat-card"><span><BookOpen size={18} /></span><b>{mangas.length}</b><small>Tổng số truyện</small></div><div className="stat-card"><span><History size={18} /></span><b>{readingCount}</b><small>Đang có lịch sử đọc</small></div><div className="stat-card"><span><Heart size={18} /></span><b>{favoriteCount}</b><small>Truyện yêu thích</small></div></div>
    <section className="settings-section"><div className="section-heading"><div><div className="eyebrow">READING HISTORY</div><h2>Lịch sử đọc gần đây</h2></div></div>{mangas.filter((manga) => progress[manga.id]).sort((a, b) => (progress[b.id]?.updatedAt || '').localeCompare(progress[a.id]?.updatedAt || '')).slice(0, 6).length ? <div className="history-list">{mangas.filter((manga) => progress[manga.id]).sort((a, b) => (progress[b.id]?.updatedAt || '').localeCompare(progress[a.id]?.updatedAt || '')).slice(0, 6).map((manga) => { const saved = progress[manga.id]; const chapter = manga.chapters.find((item) => item.id === saved.chapterId); return <Link to={chapter ? `/read/${manga.id}/${saved.chapterId}` : `/manga/${manga.id}`} className="history-row" key={manga.id}><span className="history-icon"><Clock3 size={16} /></span><div><b>{manga.title}</b><small>{chapter ? `Chương ${chapter.number} · ${chapter.title}` : 'Chương đã lưu'} · Trang {saved.page + 1}</small></div><span className="history-date">{new Date(saved.updatedAt).toLocaleDateString('vi-VN')}</span></Link>; })}</div> : <div className="empty-inline">Bạn chưa có lịch sử đọc. Mở một chương để tiến trình đọc được lưu ở đây.</div>}</section>
    <section className="settings-section"><div className="section-heading"><div><div className="eyebrow">PREFERENCES</div><h2>Cài đặt giao diện</h2></div></div><div className="setting-row"><div className="setting-icon"><Sun size={18} /></div><div className="setting-copy"><b>Giao diện</b><small>Chọn chế độ phù hợp với mắt của bạn</small></div><button className="theme-switch" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? <><Moon size={15} /> Tối</> : <><Sun size={15} /> Sáng</>}</button></div><div className="setting-row"><div className="setting-icon"><History size={18} /></div><div className="setting-copy"><b>Ngôn ngữ</b><small>Ngôn ngữ hiển thị hiện tại</small></div><span className="setting-value">Tiếng Việt</span></div></section>
    <section className="settings-section"><div className="section-heading"><div><div className="eyebrow">DATA MANAGEMENT</div><h2>Dữ liệu cá nhân</h2></div></div><div className="data-actions"><button className="data-action" onClick={exportData}><span><Download size={18} /></span><div><b>Xuất bản sao lưu</b><small>Tải xuống truyện, tủ sách và tiến trình đọc dạng JSON.</small></div></button><button className="data-action" onClick={() => fileRef.current?.click()}><span><Upload size={18} /></span><div><b>Nhập bản sao lưu</b><small>Khôi phục dữ liệu từ tệp JSON đã xuất trước đó.</small></div></button><input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => importData(e.target.files?.[0])} /><button className="data-action danger" onClick={clearData}><span><Trash2 size={18} /></span><div><b>Xóa toàn bộ dữ liệu</b><small>Xóa dữ liệu lưu trên trình duyệt của thiết bị này.</small></div></button></div>{notice && <div className="tiny-feedback">{notice}</div>}</section>
    <div className="privacy-note"><AlertTriangle size={17} /><p>Không có đăng nhập hoặc đồng bộ đám mây trong phiên bản này. Dữ liệu LocalStorage có thể mất khi bạn xóa dữ liệu trình duyệt hoặc đổi thiết bị. Hãy xuất bản sao lưu định kỳ.</p></div>
  </div>;
}
