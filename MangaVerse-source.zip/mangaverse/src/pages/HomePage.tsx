import { ArrowRight, BookOpen, Compass, Plus, Sparkles, WandSparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { MangaCard, SectionHeading, EmptyState } from '../components/MangaCard';
import { useStore } from '../store';

export default function HomePage() {
  const { mangas, progress } = useStore();
  const latest = mangas.flatMap((manga) => manga.chapters.map((chapter) => ({ manga, chapter }))).sort((a, b) => b.chapter.updatedAt.localeCompare(a.chapter.updatedAt)).slice(0, 6);
  const continueReading = mangas.filter((manga) => progress[manga.id]).slice(0, 6);
  return (
    <div className="page home-page">
      <section className="hero-panel">
        <div className="hero-glow glow-a" /><div className="hero-glow glow-b" />
        <div className="hero-content">
          <div className="hero-kicker"><Sparkles size={14} /> YOUR PERSONAL COMIC UNIVERSE</div>
          <h1>Mở cánh cửa.<br /><span>Khám phá thế giới.</span></h1>
          <p>Manga, Manhwa, Manhua — tất cả hành trình đọc của bạn, gói gọn trong một thư viện.</p>
          <div className="hero-actions"><Link className="btn btn-primary" to="/library">Khám phá thư viện <ArrowRight size={17} /></Link><Link className="btn btn-glass" to="/discover"><Compass size={17} /> Tìm trên AniList</Link></div>
          <div className="hero-footnote"><span className="pulse-dot" /> Không gian đọc của riêng bạn</div>
        </div>
        <div className="hero-visual" aria-hidden="true"><div className="portal portal-back" /><div className="portal portal-front"><div className="portal-core">M<span>V</span></div></div><div className="floating-chip chip-top"><WandSparkles size={15} /> Fantasy worlds</div><div className="floating-chip chip-bottom"><BookOpen size={15} /> One more chapter</div><div className="orbit orbit-one" /><div className="orbit orbit-two" /></div>
      </section>

      <div className="quick-grid">
        <Link to="/library" className="quick-card"><span className="quick-icon purple"><BookOpen size={20} /></span><div><b>Thư viện truyện</b><small>{mangas.length} bộ truyện của bạn</small></div><ArrowRight size={16} /></Link>
        <Link to="/admin" className="quick-card"><span className="quick-icon blue"><Plus size={20} /></span><div><b>Thêm truyện mới</b><small>Tạo bộ truyện của riêng bạn</small></div><ArrowRight size={16} /></Link>
      </div>

      {continueReading.length > 0 && <section className="content-section"><SectionHeading eyebrow="PICK UP WHERE YOU LEFT OFF" title="Đọc tiếp" link={<Link className="text-link" to="/shelf">Tủ sách <ArrowRight size={14} /></Link>} /><div className="manga-grid">{continueReading.map((manga) => <MangaCard key={manga.id} manga={manga} />)}</div></section>}

      <section className="content-section"><SectionHeading eyebrow="LATEST UPDATES" title="Mới cập nhật" link={<Link className="text-link" to="/library">Xem thư viện <ArrowRight size={14} /></Link>} />
        {latest.length ? <div className="manga-grid">{latest.map(({ manga }) => <MangaCard key={manga.id} manga={manga} />)}</div> : <EmptyState title="Chưa có chương mới" text="Khi bạn thêm truyện và chương trong khu vực quản trị, các cập nhật mới sẽ xuất hiện tại đây." action={<Link className="btn btn-secondary" to="/admin"><Plus size={16} /> Thêm truyện đầu tiên</Link>} />}
      </section>
      <section className="home-note"><div className="note-icon"><Sparkles size={20} /></div><div><b>Thư viện bắt đầu từ lựa chọn của bạn</b><p>MangaVerse không tự thêm truyện có bản quyền. Bạn tự quản lý bìa, thông tin, chương và ảnh đọc được phép sử dụng.</p></div><Link to="/admin" aria-label="Mở quản trị"><ArrowRight size={19} /></Link></section>
    </div>
  );
}
