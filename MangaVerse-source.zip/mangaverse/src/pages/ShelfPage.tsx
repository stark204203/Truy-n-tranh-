import { useMemo, useState } from 'react';
import { BookOpen, Heart, Bookmark, Clock3, CheckCircle2, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { EmptyState, MangaCard, SectionHeading } from '../components/MangaCard';
import { useStore } from '../store';

const tabs = [{ id: 'all', label: 'Tất cả' }, { id: 'favorite', label: 'Yêu thích' }, { id: 'following', label: 'Theo dõi' }, { id: 'reading', label: 'Đang đọc' }, { id: 'complete', label: 'Hoàn thành' }];
export default function ShelfPage() {
  const { mangas, shelf, setShelf, progress } = useStore();
  const [tab, setTab] = useState('all');
  const saved = useMemo(() => {
    return mangas.filter((manga) => {
      const entry = shelf.find((item) => item.mangaId === manga.id);
      if (tab === 'favorite') return entry?.favorite;
      if (tab === 'following') return entry?.following;
      if (tab === 'reading') return Boolean(progress[manga.id]);
      if (tab === 'complete') return entry?.completed;
      return Boolean(entry || progress[manga.id]);
    });
  }, [mangas, shelf, progress, tab]);
  const remove = (id: string) => setShelf((items) => items.filter((item) => item.mangaId !== id));
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">YOUR PERSONAL SPACE</div><h1>Tủ sách của bạn</h1><p>Theo dõi hành trình đọc và lưu lại những bộ truyện yêu thích.</p></div><div className="shelf-total"><b>{saved.length}</b><span>tác phẩm</span></div></div>
    <div className="shelf-tabs">{tabs.map((item) => <button key={item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>{item.label}</button>)}</div>
    {saved.length ? <div className="shelf-grid">{saved.map((manga) => <div className="shelf-item" key={manga.id}><MangaCard manga={manga} /><div className="shelf-item-actions"><Link to={`/manga/${manga.id}`}><BookOpen size={14} /> Chi tiết</Link><button onClick={() => remove(manga.id)}><Trash2 size={14} /> Bỏ khỏi tủ</button></div>{progress[manga.id] && <div className="progress-note"><Clock3 size={12} /> Đọc gần nhất: trang {progress[manga.id].page + 1}</div>}</div>)}</div> : <EmptyState title="Tủ sách còn trống" text="Thêm truyện vào mục yêu thích hoặc theo dõi để chúng xuất hiện ở đây." action={<Link className="btn btn-primary" to="/library">Khám phá thư viện</Link>} />}
    <div className="shelf-tip"><div><Heart size={17} /><Bookmark size={17} /><CheckCircle2 size={17} /></div><p>Tủ sách được lưu trên trình duyệt và thiết bị hiện tại bằng LocalStorage. Dữ liệu không tự đồng bộ sang thiết bị khác.</p></div>
  </div>;
}
