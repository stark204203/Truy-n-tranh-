import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ChevronLeft, ChevronRight, List, Maximize2, Minus, Plus, Settings2, SunMoon, X } from 'lucide-react';
import { useStore } from '../store';
import { makeId } from '../lib/storage';

const PREVIEW_PAGES = ['./reader-demo/page-01.svg', './reader-demo/page-02.svg', './reader-demo/page-03.svg'];

export default function ReaderPage() {
  const { mangaId, chapterId } = useParams();
  const navigate = useNavigate();
  const { mangas, progress, setProgress, readerMode, setReaderMode } = useStore();
  const manga = mangas.find((item) => item.id === mangaId);
  const preview = chapterId === 'preview' || !mangaId;
  const chapter = manga?.chapters.find((item) => item.id === chapterId);
  const chapters = useMemo(() => manga ? [...manga.chapters].sort((a, b) => a.number - b.number) : [], [manga]);
  const chapterIndex = chapter ? chapters.findIndex((item) => item.id === chapter.id) : -1;
  const pages = preview ? PREVIEW_PAGES : chapter?.pages || [];
  const saved = manga && chapter ? progress[manga.id] : undefined;
  const [page, setPage] = useState(saved?.chapterId === chapter?.id ? saved.page : 0);
  const [toolbar, setToolbar] = useState(true);
  const [night, setNight] = useState(false);
  const [scale, setScale] = useState(100);
  const [listOpen, setListOpen] = useState(false);
  const [failed, setFailed] = useState<number[]>([]);
  const readerRef = useRef<HTMLDivElement>(null);
  const progressTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    setPage(saved?.chapterId === chapter?.id ? saved.page : 0);
    setFailed([]);
  // The selected chapter changes when the route changes.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapterId]);

  useEffect(() => {
    const nextImage = pages[page + 1];
    if (nextImage) { const preload = new Image(); preload.src = nextImage; }
  }, [page, pages]);

  useEffect(() => {
    if (readerMode !== 'vertical' || !pages.length || preview) return;
    const frame = window.requestAnimationFrame(() => {
      const target = readerRef.current?.querySelector<HTMLElement>(`[data-page="${page}"]`);
      target?.scrollIntoView({ block: 'start' });
    });
    return () => window.cancelAnimationFrame(frame);
  // Restore a previously saved vertical position when the chapter opens.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapterId, readerMode]);

  const save = (nextPage: number, mode = readerMode) => {
    if (!manga || !chapter) return;
    setProgress((items) => ({ ...items, [manga.id]: { mangaId: manga.id, chapterId: chapter.id, page: nextPage, mode, updatedAt: new Date().toISOString() } }));
  };
  const changePage = (next: number) => { const value = Math.max(0, Math.min(pages.length - 1, next)); setPage(value); save(value, 'single'); };
  const changeChapter = (direction: -1 | 1) => {
    if (chapterIndex < 0) return;
    const target = chapters[chapterIndex + direction];
    if (target && manga) navigate(`/read/${manga.id}/${target.id}`);
  };
  const toggleFullscreen = async () => {
    try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); } catch { /* Fullscreen may be unavailable in embedded browsers. */ }
  };
  const onVerticalScroll = () => {
    if (!manga || !chapter || !readerRef.current) return;
    const images = Array.from(readerRef.current.querySelectorAll<HTMLElement>('[data-page]'));
    const current = images.findIndex((element) => element.getBoundingClientRect().bottom > 120);
    if (current >= 0 && current !== page) {
      setPage(current);
      window.clearTimeout(progressTimer.current);
      progressTimer.current = window.setTimeout(() => save(current, 'vertical'), 450);
    }
  };
  const onModeChange = (mode: 'vertical' | 'single') => { setReaderMode(mode); save(page, mode); };
  if (!preview && (!manga || !chapter)) return <div className="reader-not-found"><h2>Không tìm thấy chương truyện</h2><p>Hãy kiểm tra lại chương hoặc quay về thư viện.</p><Link className="btn btn-secondary" to="/library">Về thư viện</Link></div>;
  if (!pages.length) return <div className="reader-not-found"><h2>Chương chưa có ảnh</h2><p>Hãy thêm URL ảnh trang truyện trong khu vực Quản lý nội dung.</p><Link to={`/manga/${manga?.id}`} className="btn btn-secondary">Quay lại chi tiết</Link></div>;

  return <div className={`reader-page ${night ? 'reader-night' : ''}`}>
    <div className="reader-progress-top"><span style={{ width: `${((page + 1) / pages.length) * 100}%` }} /></div>
    <div className={`reader-toolbar ${toolbar ? 'visible' : 'hidden'}`}><div className="reader-toolbar-left"><button className="reader-icon" onClick={() => navigate(manga ? `/manga/${manga.id}` : '/')} aria-label="Thoát trình đọc"><ArrowLeft size={19} /></button><div className="reader-heading"><b>{manga?.title || 'MangaVerse — Xem trước'}</b><span>{chapter?.title || 'Chương demo · Giao diện đọc'}</span></div></div><div className="reader-toolbar-actions"><button className="reader-icon" onClick={() => setListOpen(!listOpen)} aria-label="Danh sách chương"><List size={18} /></button><button className="reader-mode-switch" onClick={() => onModeChange(readerMode === 'vertical' ? 'single' : 'vertical')}>{readerMode === 'vertical' ? 'Cuộn dọc' : 'Từng trang'}</button><button className="reader-icon" onClick={() => setNight(!night)} aria-label="Chế độ ban đêm"><SunMoon size={18} /></button><button className="reader-icon" onClick={toggleFullscreen} aria-label="Toàn màn hình"><Maximize2 size={17} /></button><button className="reader-icon" onClick={() => setToolbar(false)} aria-label="Ẩn thanh công cụ"><X size={17} /></button></div></div>
    {!toolbar && <button className="reader-reveal" onClick={() => setToolbar(true)} aria-label="Hiện thanh công cụ"><Settings2 size={18} /></button>}
    {listOpen && <div className="reader-chapter-popover"><div className="popover-head"><b>Danh sách chương</b><button onClick={() => setListOpen(false)}><X size={16} /></button></div>{chapters.map((item) => <button key={item.id} className={item.id === chapterId ? 'active' : ''} onClick={() => { setListOpen(false); navigate(`/read/${mangaId}/${item.id}`); }}>{`Chương ${item.number}`} · {item.title}</button>)}</div>}
    <div className="reader-workspace" ref={readerRef} onScroll={readerMode === 'vertical' ? onVerticalScroll : undefined} onClick={() => { if (!toolbar) setToolbar(true); }}>
      {readerMode === 'vertical' ? <div className="vertical-pages">{pages.map((src, index) => <div className="reader-image-wrap" key={`${chapterId}-${index}`} data-page={index}><img src={src} alt={`Trang ${index + 1}`} loading={index < 2 ? 'eager' : 'lazy'} onError={() => setFailed((items) => items.includes(index) ? items : [...items, index])} />{failed.includes(index) && <div className="image-error"><b>Không tải được trang {index + 1}</b><span>Kiểm tra URL ảnh hoặc kết nối mạng.</span></div>}</div>)}</div> : <div className="single-page-view"><button className="page-arrow" disabled={page === 0} onClick={() => changePage(page - 1)}><ChevronLeft size={28} /></button><div className="single-image-wrap"><img src={pages[page]} alt={`Trang ${page + 1}`} style={{ transform: `scale(${scale / 100})` }} onError={() => setFailed((items) => items.includes(page) ? items : [...items, page])} />{failed.includes(page) && <div className="image-error"><b>Không tải được ảnh</b><span>Hãy kiểm tra lại địa chỉ ảnh.</span></div>}</div><button className="page-arrow" disabled={page >= pages.length - 1} onClick={() => changePage(page + 1)}><ChevronRight size={28} /></button></div>}
    </div>
    {readerMode === 'single' && <div className={`reader-bottom-controls ${toolbar ? 'visible' : 'hidden'}`}><div className="zoom-controls"><button onClick={() => setScale((n) => Math.max(60, n - 10))}><Minus size={15} /></button><span>{scale}%</span><button onClick={() => setScale((n) => Math.min(150, n + 10))}><Plus size={15} /></button></div><div className="page-counter">{page + 1} / {pages.length}</div><input type="range" min="0" max={pages.length - 1} value={page} onChange={(e) => changePage(Number(e.target.value))} aria-label="Chọn trang" /></div>}
    <div className={`reader-footer-nav ${toolbar ? 'visible' : 'hidden'}`}><button className="btn btn-secondary" disabled={preview || chapterIndex <= 0} onClick={() => changeChapter(-1)}><ChevronLeft size={16} /> Chương trước</button><span>Trang {page + 1} / {pages.length}</span><button className="btn btn-primary" disabled={preview || chapterIndex >= chapters.length - 1} onClick={() => changeChapter(1)}>Chương tiếp <ChevronRight size={16} /></button></div>
  </div>;
}
