import { useMemo, useState, type FormEvent } from 'react';
import { AlertTriangle, BookPlus, Check, Edit3, ImagePlus, Plus, Save, Trash2, X } from 'lucide-react';
import { useStore } from '../store';
import { makeId } from '../lib/storage';
import type { Chapter, Manga, MangaFormat, MangaStatus } from '../types';
import { Cover } from '../components/MangaCard';

const emptyForm = { title: '', altTitle: '', format: 'Manga' as MangaFormat, cover: '', description: '', author: '', artist: '', country: 'JP', status: 'Đang tiến hành' as MangaStatus, year: '', score: '', genres: '' };
export default function AdminPage() {
  const { mangas, setMangas, setShelf, setProgress } = useStore();
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState('');
  const [chapterNumber, setChapterNumber] = useState('1');
  const [chapterTitle, setChapterTitle] = useState('');
  const [pageUrls, setPageUrls] = useState('');
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [notice, setNotice] = useState('');
  const selectedManga = mangas.find((manga) => manga.id === selectedId);
  const sortedMangas = useMemo(() => [...mangas].sort((a, b) => a.title.localeCompare(b.title, 'vi')), [mangas]);
  const updateForm = (key: keyof typeof emptyForm, value: string) => setForm((current) => ({ ...current, [key]: value } as typeof emptyForm));
  const submitManga = (event: FormEvent) => {
    event.preventDefault();
    if (!form.title.trim()) { setNotice('Vui lòng nhập tên truyện.'); return; }
    const manga: Manga = {
      id: editingId || makeId('manga'), title: form.title.trim(), altTitle: form.altTitle.trim(), format: form.format,
      cover: form.cover.trim(), description: form.description.trim(), author: form.author.trim() || 'Chưa cập nhật', artist: form.artist.trim() || 'Chưa cập nhật', country: form.country.trim() || 'Chưa cập nhật',
      status: form.status, year: form.year ? Number(form.year) : null, score: form.score ? Number(form.score) : null,
      genres: form.genres.split(',').map((item) => item.trim()).filter(Boolean), chapters: mangas.find((item) => item.id === editingId)?.chapters || [], source: 'local',
    };
    setMangas((items) => editingId ? items.map((item) => item.id === editingId ? manga : item) : [manga, ...items]);
    setSelectedId(manga.id); setForm(emptyForm); setEditingId(null); setNotice(editingId ? 'Đã cập nhật thông tin truyện.' : 'Đã thêm truyện mới vào thư viện.');
  };
  const editManga = (manga: Manga) => {
    setEditingId(manga.id); setSelectedId(manga.id);
    setForm({ title: manga.title, altTitle: manga.altTitle || '', format: manga.format, cover: manga.cover, description: manga.description, author: manga.author, artist: manga.artist, country: manga.country, status: manga.status, year: manga.year?.toString() || '', score: manga.score?.toString() || '', genres: manga.genres.join(', ') });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const deleteManga = (manga: Manga) => {
    if (!window.confirm(`Xóa “${manga.title}” cùng toàn bộ chương của truyện này?`)) return;
    setMangas((items) => items.filter((item) => item.id !== manga.id));
    setShelf((items) => items.filter((item) => item.mangaId !== manga.id));
    setProgress((items) => { const next = { ...items }; delete next[manga.id]; return next; });
    if (selectedId === manga.id) setSelectedId('');
    if (editingId === manga.id) { setEditingId(null); setForm(emptyForm); }
    setNotice('Đã xóa truyện.');
  };
  const addChapter = (event: FormEvent) => {
    event.preventDefault();
    if (!selectedManga) { setNotice('Hãy chọn bộ truyện trước.'); return; }
    const number = Number(chapterNumber);
    const pages = pageUrls.split('\n').map((item) => item.trim()).filter(Boolean);
    if (!Number.isFinite(number) || number < 0) { setNotice('Số chương không hợp lệ.'); return; }
    if (!pages.length) { setNotice('Hãy thêm ít nhất một URL ảnh trang truyện.'); return; }
    const chapter: Chapter = { id: editingChapterId || makeId('chapter'), number, title: chapterTitle.trim() || `Chương ${number}`, updatedAt: new Date().toISOString(), pages };
    setMangas((items) => items.map((item) => item.id === selectedId ? { ...item, chapters: [...item.chapters.filter((old) => old.id !== chapter.id && old.number !== number), chapter].sort((a, b) => a.number - b.number) } : item));
    setChapterNumber(String(number + 1)); setChapterTitle(''); setPageUrls(''); setNotice(editingChapterId ? `Đã cập nhật chương ${number}.` : `Đã thêm chương ${number} với ${pages.length} trang ảnh.`); setEditingChapterId(null);
  };
  const editChapter = (chapter: Chapter) => {
    setEditingChapterId(chapter.id); setChapterNumber(String(chapter.number)); setChapterTitle(chapter.title); setPageUrls(chapter.pages.join('\n'));
    document.querySelector('.chapter-form')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  const deleteChapter = (chapterId: string) => {
    if (!selectedManga || !window.confirm('Xóa chương này?')) return;
    if (editingChapterId === chapterId) { setEditingChapterId(null); setChapterTitle(''); setPageUrls(''); }
    setProgress((items) => { const next = { ...items }; if (next[selectedId]?.chapterId === chapterId) delete next[selectedId]; return next; });
    setMangas((items) => items.map((item) => item.id === selectedId ? { ...item, chapters: item.chapters.filter((chapter) => chapter.id !== chapterId) } : item));
    setNotice('Đã xóa chương.');
  };
  return <div className="page admin-page"><div className="page-heading"><div><div className="eyebrow">CONTENT STUDIO</div><h1>Quản lý nội dung</h1><p>Tạo bộ truyện, cập nhật metadata và thêm ảnh chương.</p></div><span className="local-badge">LOCAL ADMIN</span></div>
    <div className="admin-warning"><AlertTriangle size={18} /><div><b>Chế độ quản trị cục bộ — chưa có bảo mật máy chủ</b><p>Dữ liệu chỉ lưu trên trình duyệt hiện tại. Đây không phải hệ thống admin bảo mật và không đồng bộ cho người xem khác. Trước khi xuất bản nội dung công khai, cần bổ sung backend, đăng nhập và phân quyền.</p></div></div>
    {notice && <div className="admin-notice"><Check size={16} /> {notice}<button onClick={() => setNotice('')}><X size={15} /></button></div>}
    <section className="admin-section"><div className="section-heading"><div><div className="eyebrow">01 / MANGA METADATA</div><h2>{editingId ? 'Chỉnh sửa truyện' : 'Tạo bộ truyện mới'}</h2></div></div>
      <form className="admin-form" onSubmit={submitManga}><div className="form-grid"><label className="wide">Tên truyện *<input value={form.title} onChange={(e) => updateForm('title', e.target.value)} required placeholder="Ví dụ: Tên bộ truyện của bạn" /></label><label className="wide">Tên khác<input value={form.altTitle} onChange={(e) => updateForm('altTitle', e.target.value)} placeholder="Tên tiếng Anh / Nhật / Hàn..." /></label><label>Định dạng<select value={form.format} onChange={(e) => updateForm('format', e.target.value as MangaFormat)}>{['Manga', 'Manhwa', 'Manhua', 'Webtoon', 'Other'].map((item) => <option key={item}>{item}</option>)}</select></label><label>Trạng thái<select value={form.status} onChange={(e) => updateForm('status', e.target.value as MangaStatus)}>{['Đang tiến hành', 'Đã hoàn thành', 'Tạm ngưng'].map((item) => <option key={item}>{item}</option>)}</select></label><label className="wide">URL ảnh bìa<input value={form.cover} onChange={(e) => updateForm('cover', e.target.value)} placeholder="https://... hoặc ./covers/ten-truyen.jpg" /></label><label>Tác giả<input value={form.author} onChange={(e) => updateForm('author', e.target.value)} placeholder="Tên tác giả" /></label><label>Họa sĩ<input value={form.artist} onChange={(e) => updateForm('artist', e.target.value)} placeholder="Tên họa sĩ" /></label><label>Quốc gia<input value={form.country} onChange={(e) => updateForm('country', e.target.value)} placeholder="JP / KR / CN" /></label><label>Năm phát hành<input type="number" min="1900" max="2100" value={form.year} onChange={(e) => updateForm('year', e.target.value)} placeholder="2026" /></label><label>Điểm đánh giá (0–10)<input type="number" min="0" max="10" step="0.1" value={form.score} onChange={(e) => updateForm('score', e.target.value)} placeholder="8.5" /></label><label className="wide">Thể loại<input value={form.genres} onChange={(e) => updateForm('genres', e.target.value)} placeholder="Fantasy, Action, Isekai (ngăn cách bằng dấu phẩy)" /></label><label className="wide">Mô tả<textarea rows={4} value={form.description} onChange={(e) => updateForm('description', e.target.value)} placeholder="Giới thiệu nội dung bộ truyện..." /></label></div><div className="form-actions"><button type="submit" className="btn btn-primary"><Save size={16} /> {editingId ? 'Lưu thay đổi' : 'Tạo bộ truyện'}</button>{editingId && <button type="button" className="btn btn-secondary" onClick={() => { setEditingId(null); setForm(emptyForm); }}>Hủy chỉnh sửa</button>}</div></form>
    </section>
    <section className="admin-section"><div className="section-heading"><div><div className="eyebrow">02 / CHAPTER MANAGER</div><h2>Thêm chương và ảnh trang</h2></div></div><div className="chapter-manager"><label>Chọn bộ truyện<select value={selectedId} onChange={(e) => { setSelectedId(e.target.value); setEditingChapterId(null); setChapterTitle(''); setPageUrls(''); }}><option value="">-- Chọn truyện --</option>{sortedMangas.map((manga) => <option key={manga.id} value={manga.id}>{manga.title}</option>)}</select></label>{selectedManga && <div className="selected-manga-line"><Cover manga={selectedManga} /><div><b>{selectedManga.title}</b><small>{selectedManga.chapters.length} chương hiện có</small></div></div>}
      <form className="admin-form chapter-form" onSubmit={addChapter}><div className="form-grid"><label>Số chương<input type="number" min="0" step="0.1" value={chapterNumber} onChange={(e) => setChapterNumber(e.target.value)} /></label><label>Tên chương<input value={chapterTitle} onChange={(e) => setChapterTitle(e.target.value)} placeholder="Tên chương (không bắt buộc)" /></label><label className="wide">URL ảnh từng trang <span className="field-hint">Mỗi URL đặt trên một dòng, theo đúng thứ tự đọc.</span><textarea rows={6} value={pageUrls} onChange={(e) => setPageUrls(e.target.value)} placeholder={'https://example.com/page-01.jpg\nhttps://example.com/page-02.jpg\n./manga/ten-truyen/chapter-01/page-03.jpg'} /></label></div><div className="upload-hint"><ImagePlus size={17} /><p>Ảnh có thể là URL https hoặc đường dẫn tương đối nằm trong thư mục public/. Ví dụ: <code>./manga/ten-truyen/chapter-01/01.jpg</code>. Hãy chỉ thêm ảnh bạn có quyền sử dụng.</p></div><div className="form-actions"><button className="btn btn-primary" type="submit" disabled={!selectedManga}><BookPlus size={16} /> {editingChapterId ? 'Cập nhật chương' : 'Lưu chương'}</button>{editingChapterId && <button className="btn btn-secondary" type="button" onClick={() => { setEditingChapterId(null); setChapterTitle(''); setPageUrls(''); }}>Hủy sửa chương</button>}</div></form>
      {selectedManga?.chapters.length ? <div className="admin-chapter-list">{[...selectedManga.chapters].sort((a, b) => b.number - a.number).map((chapter) => <div key={chapter.id}><span>Ch. {chapter.number} · {chapter.title} <small>{chapter.pages.length} trang</small></span><div className="chapter-row-actions"><button onClick={() => editChapter(chapter)} aria-label="Sửa chương"><Edit3 size={14} /></button><button onClick={() => deleteChapter(chapter.id)} aria-label="Xóa chương"><Trash2 size={15} /></button></div></div>)}</div> : selectedManga ? <div className="empty-inline">Bộ truyện này chưa có chương.</div> : null}</div>
    </section>
    <section className="admin-section"><div className="section-heading"><div><div className="eyebrow">03 / LIBRARY MANAGER</div><h2>Danh sách truyện <span className="muted-count">({mangas.length})</span></h2></div></div>{mangas.length ? <div className="admin-manga-list">{sortedMangas.map((manga) => <div className="admin-manga-row" key={manga.id}><Cover manga={manga} /><div className="admin-manga-copy"><b>{manga.title}</b><small>{manga.format} · {manga.chapters.length} chương</small></div><button onClick={() => editManga(manga)} aria-label="Sửa truyện"><Edit3 size={16} /></button><button className="delete-button" onClick={() => deleteManga(manga)} aria-label="Xóa truyện"><Trash2 size={16} /></button></div>)}</div> : <div className="empty-inline">Chưa có truyện nào được tạo. Điền biểu mẫu phía trên để thêm truyện đầu tiên.</div>}</section>
  </div>;
}
