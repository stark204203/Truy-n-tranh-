import { createContext, useContext, useEffect, useMemo, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import type { Manga, ReadProgress, ShelfEntry } from './types';
import { storage } from './lib/storage';

type StoreValue = {
  mangas: Manga[];
  setMangas: Dispatch<SetStateAction<Manga[]>>;
  shelf: ShelfEntry[];
  setShelf: Dispatch<SetStateAction<ShelfEntry[]>>;
  progress: Record<string, ReadProgress>;
  setProgress: Dispatch<SetStateAction<Record<string, ReadProgress>>>;
  searchHistory: string[];
  setSearchHistory: Dispatch<SetStateAction<string[]>>;
  theme: 'dark' | 'light';
  setTheme: Dispatch<SetStateAction<'dark' | 'light'>>;
  readerMode: 'vertical' | 'single';
  setReaderMode: Dispatch<SetStateAction<'vertical' | 'single'>>;
};

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [mangas, setMangas] = useState<Manga[]>(storage.getMangas);
  const [shelf, setShelf] = useState<ShelfEntry[]>(storage.getShelf);
  const [progress, setProgress] = useState<Record<string, ReadProgress>>(storage.getProgress);
  const [searchHistory, setSearchHistory] = useState<string[]>(storage.getSearchHistory);
  const [theme, setTheme] = useState<'dark' | 'light'>(storage.getTheme);
  const [readerMode, setReaderMode] = useState<'vertical' | 'single'>(storage.getReaderMode);

  useEffect(() => storage.setMangas(mangas), [mangas]);
  useEffect(() => storage.setShelf(shelf), [shelf]);
  useEffect(() => storage.setProgress(progress), [progress]);
  useEffect(() => storage.setSearchHistory(searchHistory), [searchHistory]);
  useEffect(() => {
    storage.setTheme(theme);
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  useEffect(() => storage.setReaderMode(readerMode), [readerMode]);

  const value = useMemo(() => ({ mangas, setMangas, shelf, setShelf, progress, setProgress, searchHistory, setSearchHistory, theme, setTheme, readerMode, setReaderMode }), [mangas, shelf, progress, searchHistory, theme, readerMode]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const value = useContext(StoreContext);
  if (!value) throw new Error('useStore must be used inside StoreProvider');
  return value;
}
