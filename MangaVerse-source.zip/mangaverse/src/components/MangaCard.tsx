import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';
import { BookOpen, Star } from 'lucide-react';
import type { Manga } from '../types';

export function Cover({ manga, className = '' }: { manga: Pick<Manga, 'title' | 'cover'>; className?: string }) {
  return (
    <div className={`cover-frame ${className}`}>
      {manga.cover ? <img src={manga.cover} alt={`Bìa ${manga.title}`} loading="lazy" onError={(event) => { event.currentTarget.style.display = 'none'; }} /> : null}
      <div className="cover-fallback"><span className="cover-mark">MV</span><span>{manga.title}</span></div>
    </div>
  );
}

export function MangaCard({ manga }: { manga: Manga }) {
  const latest = [...manga.chapters].sort((a, b) => b.number - a.number)[0];
  return (
    <Link to={`/manga/${manga.id}`} className="manga-card">
      <Cover manga={manga} />
      <div className="manga-card-info">
        <div className="manga-card-title">{manga.title}</div>
        <div className="manga-card-meta"><span>{manga.format}</span><span className="rating"><Star size={12} fill="currentColor" /> {manga.score ? manga.score.toFixed(1) : '—'}</span></div>
        <div className="manga-card-latest"><BookOpen size={12} /> {latest ? `Ch. ${latest.number}` : 'Chưa có chương'}</div>
      </div>
    </Link>
  );
}

export function EmptyState({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-art"><div className="empty-book"><span /><span /></div><i className="empty-spark spark-one" /><i className="empty-spark spark-two" /></div><h3>{title}</h3><p>{text}</p>{action}</div>;
}

export function SectionHeading({ eyebrow, title, link }: { eyebrow?: string; title: string; link?: React.ReactNode }) {
  return <div className="section-heading"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h2>{title}</h2></div>{link}</div>;
}
