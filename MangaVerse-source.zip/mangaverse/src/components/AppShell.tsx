import { useState, type FormEvent } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { BookMarked, BookOpen, Compass, Home, Library, Moon, Search, Sun, UserRound, Plus, Sparkles } from 'lucide-react';
import { useStore } from '../store';

export default function AppShell() {
  const { theme, setTheme, mangas } = useStore();
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const submit = (event: FormEvent) => {
    event.preventDefault();
    navigate(`/library?q=${encodeURIComponent(query.trim())}`);
  };
  const nav = [
    { to: '/', label: 'Trang chủ', icon: Home, end: true },
    { to: '/library', label: 'Thư viện', icon: Library },
    { to: '/discover', label: 'Khám phá', icon: Compass },
    { to: '/shelf', label: 'Tủ sách', icon: BookMarked },
    { to: '/profile', label: 'Cá nhân', icon: UserRound },
  ];
  return (
    <div className="app-shell">
      <header className="topbar">
        <NavLink to="/" className="brand"><span className="brand-mark">M</span><span>Manga<span>Verse</span><small>READ BEYOND WORLDS</small></span></NavLink>
        <form className="top-search" onSubmit={submit}><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm truyện trong thư viện..." aria-label="Tìm truyện" /><kbd>↵</kbd></form>
        <div className="topbar-actions"><span className="library-count"><BookOpen size={14} /> {mangas.length} truyện</span><button className="icon-btn theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Đổi giao diện">{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button><NavLink className="avatar-btn" to="/profile">M</NavLink></div>
      </header>
      <div className="app-layout">
        <aside className="sidebar"><div className="sidebar-label">MENU CHÍNH</div>{nav.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}><Icon size={18} /><span>{label}</span></NavLink>)}<div className="sidebar-divider" /><div className="sidebar-label">CÔNG CỤ</div><NavLink to="/admin" className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}><Plus size={18} /><span>Quản lý nội dung</span></NavLink><div className="sidebar-tip"><div className="tip-orb"><Sparkles size={17} /></div><b>Build your universe</b><p>Tạo thư viện truyện theo sở thích của bạn.</p><NavLink to="/admin">Bắt đầu <span>↗</span></NavLink></div><div className="sidebar-footer">MangaVerse <span>v1.0.0</span></div></aside>
        <main className="main-area"><Outlet /></main>
      </div>
      <nav className="mobile-nav" aria-label="Điều hướng chính">{nav.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `mobile-nav-item ${isActive ? 'active' : ''}`}><Icon size={19} /><span>{label}</span></NavLink>)}</nav>
    </div>
  );
}
