import type { AniListManga, Manga, MangaFormat, MangaStatus } from '../types';

const ENDPOINT = 'https://graphql.anilist.co';
const QUERY = `
query ($search: String!) {
  Page(page: 1, perPage: 18) {
    media(search: $search, type: MANGA, isAdult: false, sort: POPULARITY_DESC) {
      id
      title { romaji english native }
      coverImage { extraLarge large }
      description(asHtml: false)
      genres
      averageScore
      status
      format
      chapters
      startDate { year }
      countryOfOrigin
      siteUrl
      staff(perPage: 5) { edges { role node { name { full } } } }
    }
  }
}`;

export async function searchAniList(search: string, signal?: AbortSignal): Promise<AniListManga[]> {
  const cacheKey = `mangaverse.v1.anilist.${search.trim().toLowerCase()}`;
  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached) as { expiresAt: number; results: AniListManga[] };
      if (parsed.expiresAt > Date.now() && Array.isArray(parsed.results)) return parsed.results;
      localStorage.removeItem(cacheKey);
    }
  } catch { /* Ignore malformed or unavailable browser cache. */ }
  const response = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query: QUERY, variables: { search } }),
    signal,
  });
  if (!response.ok) {
    const message = response.status === 429 ? 'AniList đang giới hạn yêu cầu. Hãy thử lại sau.' : `AniList trả về lỗi ${response.status}.`;
    throw new Error(message);
  }
  const json = await response.json();
  if (json.errors?.length) throw new Error(json.errors[0].message || 'Không thể tìm dữ liệu AniList.');
  const results = (json.data?.Page?.media || []) as AniListManga[];
  try { localStorage.setItem(cacheKey, JSON.stringify({ expiresAt: Date.now() + 30 * 60 * 1000, results })); } catch { /* The API result remains usable if browser storage is full. */ }
  return results;
}

export function fromAniList(item: AniListManga): Manga {
  const rawFormat = (item.format || '').toUpperCase();
  const format: MangaFormat = rawFormat === 'MANHWA' ? 'Manhwa' : rawFormat === 'MANHUA' ? 'Manhua' : rawFormat === 'MANGA' || rawFormat === 'ONE_SHOT' ? 'Manga' : rawFormat === 'WEBTOON' ? 'Webtoon' : 'Other';
  const status: MangaStatus = item.status === 'FINISHED' ? 'Đã hoàn thành' : item.status === 'HIATUS' || item.status === 'CANCELLED' ? 'Tạm ngưng' : 'Đang tiến hành';
  const author = item.staff?.edges?.find((edge) => /story|writer|author/i.test(edge.role || ''))?.node?.name?.full || 'Chưa cập nhật';
  return {
    id: `anilist-${item.id}`,
    title: item.title.english || item.title.romaji || item.title.native || `Manga ${item.id}`,
    altTitle: [item.title.romaji, item.title.native].filter(Boolean).join(' · '),
    format,
    cover: item.coverImage.extraLarge || item.coverImage.large || '',
    description: (item.description || 'AniList chưa cung cấp mô tả cho tác phẩm này.').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').trim(),
    author,
    artist: 'Chưa cập nhật',
    country: item.countryOfOrigin || 'Chưa cập nhật',
    status,
    year: item.startDate?.year || null,
    score: item.averageScore ? item.averageScore / 10 : null,
    genres: item.genres || [],
    chapters: [],
    source: 'anilist',
    externalUrl: item.siteUrl,
  };
}
