import type { Manga, ReadProgress, ShelfEntry } from '../types';

const KEYS = {
  mangas: 'mangaverse.v1.mangas',
  shelf: 'mangaverse.v1.shelf',
  progress: 'mangaverse.v1.progress',
  history: 'mangaverse.v1.search-history',
  theme: 'mangaverse.v1.theme',
  readerMode: 'mangaverse.v1.reader-mode',
};

function read<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    window.dispatchEvent(new CustomEvent('mangaverse:storage-full'));
  }
}

export const storage = {
  getMangas: () => read<Manga[]>(KEYS.mangas, []),
  setMangas: (value: Manga[]) => write(KEYS.mangas, value),
  getShelf: () => read<ShelfEntry[]>(KEYS.shelf, []),
  setShelf: (value: ShelfEntry[]) => write(KEYS.shelf, value),
  getProgress: () => read<Record<string, ReadProgress>>(KEYS.progress, {}),
  setProgress: (value: Record<string, ReadProgress>) => write(KEYS.progress, value),
  getSearchHistory: () => read<string[]>(KEYS.history, []),
  setSearchHistory: (value: string[]) => write(KEYS.history, value),
  getTheme: () => read<'dark' | 'light'>(KEYS.theme, 'dark'),
  setTheme: (value: 'dark' | 'light') => write(KEYS.theme, value),
  getReaderMode: () => read<'vertical' | 'single'>(KEYS.readerMode, 'vertical'),
  setReaderMode: (value: 'vertical' | 'single') => write(KEYS.readerMode, value),
  clearAll: () => Object.values(KEYS).forEach((key) => localStorage.removeItem(key)),
};

export function makeId(prefix = 'mv'): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
